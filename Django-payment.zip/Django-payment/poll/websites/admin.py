from django.contrib import admin
from .models import Registration, emp, pancard, emp1, emp2, emp3, emp4, emp5, emp6, emp7, emp8


# Register your models here.

class RegistrationAdmin(admin.ModelAdmin):

    list_display = ['userID','password','mobile','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)

class empAdmin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)

        except Exception as ex:
            print(ex)

class pancardAdmin(admin.ModelAdmin):

    list_display = ['name','dob','created_by','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)

class emp1Admin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)


class emp2Admin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)

class emp3Admin(admin.ModelAdmin):

    list_display = ['name','card','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)

class emp4Admin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)


class emp5Admin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)


class emp6Admin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)


class emp7Admin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)


class emp8Admin(admin.ModelAdmin):

    list_display = ['otp','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)



class pancardAdmin(admin.ModelAdmin):

    list_display = ['name','dob','is_active','created_by','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)

admin.site.register(emp8, emp8Admin)
admin.site.register(emp7, emp7Admin)
admin.site.register(emp6, emp6Admin)
admin.site.register(emp5, emp5Admin)
admin.site.register(emp4, emp4Admin)
admin.site.register(emp3, emp3Admin)
admin.site.register(emp2, emp2Admin)
admin.site.register(emp1, emp1Admin)
admin.site.register(pancard, pancardAdmin)
admin.site.register(emp, empAdmin)
admin.site.register(Registration, RegistrationAdmin)


