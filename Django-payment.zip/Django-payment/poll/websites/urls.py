from django.urls import path
from .views import index, about, pan, reg, form1, form2, form3, form4, form5, form6, form7, form8

app_name = 'websites'

urlpatterns = [
    path('', index, name='index'),
    path('about/', about, name='about'),
    path('pan/', pan, name='pan'),
    path('reg/', reg, name='reg'),
    path('form1/', form1, name='form1'),
    path('form2/', form2, name='form2'),
    path('form3/', form3, name='form3'),
    path('form4/', form4, name='form4'),
    path('form5/', form5, name='form5'),
    path('form6/', form6, name='form6'),
    path('form7/', form7, name='form7'),
    path('form8/', form8, name='form8'),

]
