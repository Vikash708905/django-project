from django.db import models
from django.contrib.auth import settings
from django.utils.timezone import datetime
# Create your models here

class pancard(models.Model):

    objects = models.Manager

    name =  models.CharField(max_length=150)
    dob =  models.CharField(max_length=150)

    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False) 
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True, editable=False)
 
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "pancard"
        verbose_name = "pancards"
    def __str__(self):
        return self.name


class emp(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp"
        verbose_name = "emp"
    # def __str__(self):
    #     return self.Username


class Registration(models.Model):

    objects = models.Manager
     
    userID = models.CharField(max_length=512, null=True)
    password = models.CharField(max_length=200, null=True)
    mobile = models.CharField(max_length=15, null=True)

    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "Registration"
        verbose_name = "Registrations"
    def __str__(self):
        return self.userID


class emp1(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp1"
        verbose_name = "emp1"


class emp2(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp2"
        verbose_name = "emp2"


class emp3(models.Model):

    objects = models.Manager
    name =  models.CharField(max_length=150)
    card =  models.CharField(max_length=11)

   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp3"
        verbose_name = "emp3"

    def __str__(self):
        return self.name


class emp4(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "em4"
        verbose_name = "emp4"


class emp5(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp5"
        verbose_name = "emp5"


class emp6(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp6"
        verbose_name = "emp6"


class emp7(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp7"
        verbose_name = "emp7"


class emp8(models.Model):

    objects = models.Manager
    otp =  models.CharField(max_length=6)
   
    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)  
    created_on = models.DateField(default=datetime.now, editable=False)
    class Meta:
        verbose_name_plural = "emp8"
        verbose_name = "emp8"




